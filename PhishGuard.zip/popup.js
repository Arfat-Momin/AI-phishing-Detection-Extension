// --- Your LEGITIMATE Hosts List (Allow-list) ---
const LEGITIMATE_HOSTS = [
  // Search & Email
  "google.com", "www.google.com", "bing.com", "www.bing.com", "yahoo.com",
  "www.yahoo.com", "duckduckgo.com", "mail.google.com", "outlook.live.com",
  "mail.yahoo.com",
  // Social Media
  "facebook.com", "www.facebook.com", "twitter.com", "www.twitter.com",
  "instagram.com", "www.instagram.com", "linkedin.com", "www.linkedin.com",
  "reddit.com", "www.reddit.com", "pinterest.com", "www.pinterest.com",
  "tiktok.com", "www.tiktok.com",
  // Shopping
  "amazon.com", "www.amazon.com", "ebay.com", "www.ebay.com", "walmart.com",
  "www.walmart.com", "target.com", "www.target.com", "bestbuy.com",
  "www.bestbuy.com", "etsy.com", "www.etsy.com", "amazon.in", "www.amazon.in",
  "flipkart.com", "www.flipkart.com", "myntra.com", "www.myntra.com",
  // Video & Streaming
  "youtube.com", "www.youtube.com", "netflix.com", "www.netflix.com",
  "hulu.com", "www.hulu.com", "disneyplus.com", "www.disneyplus.com",
  "twitch.tv", "www.twitch.tv", "vimeo.com", "www.vimeo.com",
  "www.hotstar.com",
  // News & Info
  "wikipedia.org", "www.wikipedia.org", "cnn.com", "www.cnn.com", "bbc.com",
  "www.bbc.com", "nytimes.com", "www.nytimes.com",
  // Tech & Dev
  "github.com", "www.github.com", "stackoverflow.com", "developer.mozilla.org",
  "microsoft.com", "www.microsoft.com",
  // Other
  "spotify.com", "www.spotify.com", "paypal.com", "www.paypal.com",
  "dropbox.com", "www.dropbox.com",
  // Your Added Site
  "mhssce.ac.in", "www.mhssce.ac.in"
];

// --- NEW: Your MALICIOUS Hosts List (Block-list) ---
const MALICIOUS_HOSTS = [
  "www.southbankmosaics.com", "www.uni-mainz.de", "www.voicefmradio.co.uk",
  "www.sfnmjournal.com", "www.rewildingargentina.org", "www.globalreporting.org",
  "www.saffronart.com", "www.nerdscandy.com", "www.hyderabadonline.in",
  "www.aap.org", "www.religionenlibertad.com", "www.teramill.com",
  "www.socialpolicy.org", "www.aoh61.com", "www.bulgariaski.com",
  "www.brightika.com", "www.motley.ie", "www.funzine.hu", "www.dixxon.com",
  "www.ooty.ind.in", "www.f0519141.xsph.ru", "www.shprakserf.gq",
  "www.cryptocompare.com", "www.diariodealmeria.es", "www.town.minamichita.lg.jp",
  "www.bwresearch.com", "www.musicvideoproduction.guru", "service-mitld.firebaseapp.com",
  "www.kuradox92.lima-city.de", "liuy-9a930.web.app", "www.landed.com",
  "ipfs.io", "att-103731-107123.weeblysite.com", "www.bikeseoul.com",
  "hidok4f8zl.firebaseapp.com", "www.ibeani.co.uk", "www.metroretrovintage.com",
  "www.ooguy.com", "www.vysor.io", "www.fairytalesinc.com", "www.iuhjn.pplink.club",
  "mechinchem-5cb8a.web.app", "www.salutlive.com", "www.recettessimples.fr",
  "fb-restriction-case-97be5.web.app", "pontosapontamentolu.com",
  "www.ainewsletter.com", "www.marrugeku.com.au", "www.sweatdrop.com",
  "www.komaru.today", "dev-634536.pantheonsite.io", "www.senacases.com",
  "sabadonoappmagazine.com", "www.vespatales.com", "www.nextraload.com",
  "www.klerk.ru", "www.karenmillen.com", "topaka.cloud", "www.mlpack.org",
  "metafb-tvz6efk.web.app", "www.hesselawchambers.com", "www.schmitzfotografia.com.br",
  "www.lanereport.com", "www.spg.pt", "www.coraevans.com", "www.torahmates.org",
  "www.larepublica.co", "www.pimpim.lt", "www.httpzen.fairhash.org",
  "www.cjplogger.com", "www.radware.com", "www.erlegen.de", "www.f0535398.xsph.ru",
  "ggsexpole.web.app", "www.classfmonline.com", "www.cornerstoneinsurance.ca",
  "www.varzesh3.com", "s3.amazonaws.com", "www.medicalplasticsnews.com",
  "www.gitguardian.com", "ormvoixregl1.firebaseapp.com", "www.crowncenter.com",
  "nmve.xyz", "www.maytheday.oss-ap-southeast-2.aliyuncs.com", "www.dancetheyard.org",
  "www.olly.com", "www.naturalearthdata.com", "att-104164.weeblysite.com",
  "www.frdc.com.au", "www.lukul.sk", "www.cityparkapp.pl",
  "tkmowpikuk.owl4fsrch.club", "a04854e8-0cca-4b74-80e6-aacb14a4a5f7.id.repl.co",
  "www.scandlines.dk", "www.hskonline.com", "www.nutritioncare.org",
  "www.tileandstonejournal.com", "www.c.line-design.fr", "www.capeblancoheritagesociety.com",
  "www.caterinaperez.com", "auth-document-shared.datingg-voice.workers.dev",
  "mail-service-100960.weeblysite.com", "www.aqr.com", "www.a0646498.xsph.ru",
  "helpadcase1002405739503874569.web.app", "www.poundingtherock.com",
  "www.kellerberrin.wa.gov.au", "www.stadtgarten.de",
  "noxioussweetconnections.carisss.repl.co", "www.jerode.ga", "www.ytv.co.jp",
  "www.today.uci.edu", "www.spket.com", "www.americanauctioneers.com",
  "yrislfnb.qpoe.com", "www.heramission.space", "www.circlek.org",
  "www.gunsmokenet.com", "www.bocajnarima.com", "www.raw-health-coach.com",
  "soah-b6mz-v.firebaseapp.com", "www.dlrect-smtb.jp.ap1.ib.commetryx.com",
  "www.estamos.de", "www.b7a3a060b75c7dcba9c1078d4ead51f0dc.ws",
, "www.ackerstadtpalast.de",
  "www.mro.nmt.edu", "www.aresync.com", "www.shopfiire.com", "www.doc88.com",
  "www.jab.oss-ap-southeast-1.aliyuncs.com", "www.hee.nhs.uk",
  "www.secondgeargames.com", "www.usbirthcertificates.com", "www.dslweb.de",
  "www.constructiongst.com", "www.westleyr.cf", "www.021.rs", "www.brainy.games",
  "www.irgendwie-nerdig.de", "www.peachstatearchaeologicalsociety.org",
"www.jazzmasters.nl", "syk1pe9wox.firebaseapp.com", "www.londondesignbiennale.com",
  "www.honneur-au-scoutisme.com", "glaze-maple-pantry.glitch.me", "www.leonardodavinci.net"
];

// --- This is the new, 3-tier logic ---
document.addEventListener('DOMContentLoaded', () => {
  
  const loadingDiv = document.getElementById('loading-container');
  const statusDiv = document.getElementById('status-message');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    
    // --- START: 2.5 second delay ---
    setTimeout(() => {
      
      const currentTab = tabs[0];
      
      try {
        const url = new URL(currentTab.url);
        const currentHostname = url.hostname;

        // --- ⬇️ UPDATED 3-TIER LOGIC ⬇️ ---
        
        // 1. Check MALICIOUS list first (Highest priority)
        if (MALICIOUS_HOSTS.includes(currentHostname)) {
          statusDiv.textContent = "🛑 DANGER! Phishing Site.";
          statusDiv.className = "danger";
        } 
        // 2. Check LEGITIMATE list next
        else if (LEGITIMATE_HOSTS.includes(currentHostname)) {
          statusDiv.textContent = "✅ SAFE! Legitimate Site.";
          statusDiv.className = "safe";
        }
        // 3. If it's on neither list, show a warning
        else {
          statusDiv.textContent = "⚠️ WARNING! This site is not recognized. Use at your own risk.";
          statusDiv.className = "warning";
        }
        // --- ⬆️ END OF UPDATED LOGIC ⬆️ ---

      } catch (e) {
        // Pages like "chrome://extensions" will error.
        // Show the same warning for these.
        statusDiv.textContent = "⚠️ WARNING! Cannot scan this page. Use at your own risk.";
        statusDiv.className = "warning";
      }

      // --- NOW, swap the visible divs ---
      loadingDiv.style.display = 'none'; // Hide the loading spinner
      statusDiv.style.display = 'block'; // Show the final result
      
    }, 3000); // 2500 milliseconds = 2.5 seconds
    // --- END: The delay wrapper ---

  });
});